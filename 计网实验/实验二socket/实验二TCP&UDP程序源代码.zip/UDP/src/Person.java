public class Person {
    String ip;
    Integer port;
    Person(String ip, Integer port){
        this.ip=ip;
        this.port=port;
    }
}
